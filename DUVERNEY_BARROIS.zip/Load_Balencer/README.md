# Serveur_FTP

https://github.com/rohit-takhar/ftp-client-program-in-C-vsftpd/blob/master/C/ftp_client.c

http://ps-2.kev009.com/tl/techlib/manuals/adoclib/libs/basetrf1/opendir.htm

http://pubs.opengroup.org/onlinepubs/7908799/xsh/readdir.html

http://stackoverflow.com/questions/3554120/open-directory-using-c

https://openclassrooms.com/courses/parcourir-les-dossiers-avec-dirent-h


